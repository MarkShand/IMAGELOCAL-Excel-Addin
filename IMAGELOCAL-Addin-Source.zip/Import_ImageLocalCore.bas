Attribute VB_Name = "ImageLocalCore"
Option Explicit

' IMAGELOCAL for Windows desktop Excel.
' The function queues work in memory; application events draw after calculation.
' Use a direct, single-cell formula such as =IMAGELOCAL(A2).

Private Const SHAPE_PREFIX As String = "__IMAGELOCAL_"
Private Const OWNER_TAG As String = "IMAGELOCAL/1"
Private mEvents As CImageLocalEvents
Private mPending As Object
Private mFiles As Object
Private mDrawing As Boolean

Public Sub ImageLocal_Start()
    If mPending Is Nothing Then Set mPending = CreateObject("Scripting.Dictionary")
    If mFiles Is Nothing Then Set mFiles = CreateObject("Scripting.FileSystemObject")
    If mEvents Is Nothing Then
        Set mEvents = New CImageLocalEvents
        Set mEvents.App = Application
    End If
End Sub

Public Sub ImageLocal_Stop()
    If Not mEvents Is Nothing Then Set mEvents.App = Nothing
    Set mEvents = Nothing
    Set mPending = Nothing
    Set mFiles = Nothing
    mDrawing = False
End Sub

Public Function IMAGELOCAL(ByVal FilePath As Variant) As Variant
    Dim destination As Range, source As Range
    Dim raw As Variant, picturePath As String

    On Error GoTo InvalidInput
    Application.Volatile True
    If TypeName(Application.Caller) <> "Range" Then
        IMAGELOCAL = CVErr(xlErrValue)
        Exit Function
    End If
    Set destination = Application.Caller
    If destination.CountLarge <> 1 Then
        IMAGELOCAL = "IMAGELOCAL: use one formula per cell"
        Exit Function
    End If

    If mEvents Is Nothing Then
        IMAGELOCAL = "IMAGELOCAL: enable the ImageLocal add-in"
        Exit Function
    End If
    QueuePicture destination, vbNullString

    If Not IsImageLocalFormula(destination) Then
        IMAGELOCAL = "IMAGELOCAL: use =IMAGELOCAL(path) directly"
        Exit Function
    End If

    If IsObject(FilePath) Then
        If Not TypeOf FilePath Is Excel.Range Then GoTo InvalidInput
        Set source = FilePath
        If source.CountLarge <> 1 Then GoTo InvalidInput
        raw = source.Value2
    Else
        raw = FilePath
    End If
    If IsError(raw) Then
        IMAGELOCAL = raw
        Exit Function
    End If
    If IsArray(raw) Or IsNull(raw) Then GoTo InvalidInput

    picturePath = Trim$(CStr(raw))
    If Len(picturePath) >= 2 Then
        If Left$(picturePath, 1) = Chr$(34) And Right$(picturePath, 1) = Chr$(34) Then
            picturePath = Mid$(picturePath, 2, Len(picturePath) - 2)
        End If
    End If
    If Len(picturePath) = 0 Then
        IMAGELOCAL = vbNullString
        Exit Function
    End If

    ' Avoid dependence on Excel's current working directory.
    If Not IsAbsolutePath(picturePath) Then
        IMAGELOCAL = "IMAGELOCAL: use a full local file path"
        Exit Function
    End If
    If Not mFiles.FileExists(picturePath) Then
        IMAGELOCAL = "IMAGELOCAL: file not found"
        Exit Function
    End If
    If destination.Parent.ProtectDrawingObjects Then
        IMAGELOCAL = "IMAGELOCAL: sheet drawing objects are protected"
        Exit Function
    End If

    QueuePicture destination, picturePath
    IMAGELOCAL = vbNullString
    Exit Function

InvalidInput:
    IMAGELOCAL = "IMAGELOCAL: invalid or inaccessible path"
End Function

Private Function IsAbsolutePath(ByVal picturePath As String) As Boolean
    Dim driveLetter As String
    If Left$(picturePath, 2) = "\\" Then
        IsAbsolutePath = True
    ElseIf Len(picturePath) >= 3 Then
        driveLetter = UCase$(Left$(picturePath, 1))
        IsAbsolutePath = (driveLetter >= "A" And driveLetter <= "Z" And _
                          Mid$(picturePath, 2, 2) = ":\")
    End If
End Function

Private Sub QueuePicture(ByVal destination As Range, ByVal picturePath As String)
    Dim key As String
    key = destination.Parent.Parent.Name & "|" & destination.Parent.CodeName & _
          "|" & destination.Address(False, False)
    mPending.Item(key) = Array(destination, picturePath)
End Sub

Private Function IsImageLocalFormula(ByVal cell As Range) As Boolean
    Dim formulaText As String, functionName As String
    Dim openingBracket As Long, qualifier As Long
    On Error GoTo Finished
    If Not cell.HasFormula Then Exit Function
    formulaText = UCase$(Replace$(CStr(cell.Formula), " ", vbNullString))
    If Left$(formulaText, 2) = "=@" Then formulaText = "=" & Mid$(formulaText, 3)
    openingBracket = InStr(2, formulaText, "(")
    If openingBracket < 3 Then Exit Function
    functionName = Mid$(formulaText, 2, openingBracket - 2)
    ' Excel may qualify a saved add-in formula with the add-in filename.
    qualifier = InStrRev(functionName, "!")
    If qualifier > 0 Then functionName = Mid$(functionName, qualifier + 1)
    IsImageLocalFormula = (functionName = "IMAGELOCAL")
Finished:
End Function

Private Function PictureName(ByVal cell As Range) As String
    PictureName = SHAPE_PREFIX & "R" & cell.Row & "C" & cell.Column
End Function

Private Function IsOurShape(ByVal picture As Shape) As Boolean
    On Error GoTo Finished
    IsOurShape = (Left$(picture.Name, Len(SHAPE_PREFIX)) = SHAPE_PREFIX And _
                  Left$(picture.AlternativeText, Len(OWNER_TAG)) = OWNER_TAG)
Finished:
End Function

Public Sub ImageLocal_Flush()
    Dim batch As Object, cleaned As Object
    Dim key As Variant, request As Variant, sheetKey As String
    Dim destination As Range, ws As Worksheet

    If mDrawing Then Exit Sub
    If mPending Is Nothing Then Exit Sub
    If mPending.Count = 0 Then Exit Sub
    On Error GoTo Finished
    mDrawing = True
    Set batch = mPending
    Set mPending = CreateObject("Scripting.Dictionary")
    Set cleaned = CreateObject("Scripting.Dictionary")

    For Each key In batch.Keys
        request = batch.Item(key)
        Set destination = Nothing
        Set ws = Nothing
        ' A workbook may have closed since the request was queued.
        On Error Resume Next
        Set destination = request(0)
        Set ws = destination.Parent
        On Error GoTo Finished
        If Not ws Is Nothing Then
            sheetKey = ws.Parent.Name & "|" & ws.CodeName
            If Not cleaned.Exists(sheetKey) Then
                ImageLocal_CleanSheet ws
                cleaned.Add sheetKey, True
            End If
            DrawPicture destination, CStr(request(1))
        End If
    Next key
Finished:
    mDrawing = False
End Sub

Public Sub ImageLocal_CleanSheet(ByVal ws As Worksheet)
    Dim i As Long, picture As Shape, anchor As Range
    Dim removeIt As Boolean
    On Error GoTo Finished
    If ws.ProtectDrawingObjects Then Exit Sub
    For i = ws.Shapes.Count To 1 Step -1
        Set picture = ws.Shapes(i)
        If IsOurShape(picture) Then
            Set anchor = picture.TopLeftCell.MergeArea.Cells(1, 1)
            removeIt = Not IsImageLocalFormula(anchor)
            If Not removeIt Then removeIt = (picture.Name <> PictureName(anchor))
            If removeIt Then picture.Delete
        End If
    Next i
Finished:
End Sub

Private Function ExistingPicture(ByVal ws As Worksheet, ByVal name As String) As Shape
    Dim candidate As Shape
    On Error Resume Next
    Set candidate = ws.Shapes(name)
    On Error GoTo 0
    If Not candidate Is Nothing Then
        If IsOurShape(candidate) Then Set ExistingPicture = candidate
    End If
End Function

Private Sub DrawPicture(ByVal destination As Range, ByVal picturePath As String)
    Dim ws As Worksheet, box As Range
    Dim picture As Shape, oldPicture As Shape, sourceFile As Object
    Dim name As String, signature As String
    Dim failureText As String

    On Error GoTo Failed
    Set ws = destination.Parent
    If Not IsImageLocalFormula(destination) Then Exit Sub
    If ws.ProtectDrawingObjects Then Exit Sub
    Set box = destination.MergeArea
    name = PictureName(destination)
    Set oldPicture = ExistingPicture(ws, name)

    If Len(picturePath) = 0 Then
        If Not oldPicture Is Nothing Then oldPicture.Delete
        Exit Sub
    End If

    Set sourceFile = mFiles.GetFile(picturePath)
    signature = OWNER_TAG & vbLf & picturePath & vbLf & _
                CStr(sourceFile.DateLastModified) & "|" & CStr(sourceFile.Size)
    If Not oldPicture Is Nothing Then
        If oldPicture.Type = msoPicture Then
            If oldPicture.AlternativeText = signature Then
                FitPicture oldPicture, box
                Exit Sub
            End If
        End If
    End If

    Set picture = ws.Shapes.AddPicture( _
        Filename:=picturePath, LinkToFile:=msoFalse, SaveWithDocument:=msoTrue, _
        Left:=box.Left, Top:=box.Top, Width:=-1, Height:=-1)
    If Not oldPicture Is Nothing Then oldPicture.Delete
    Set oldPicture = Nothing
    picture.Name = name
    picture.AlternativeText = signature
    FitPicture picture, box
    Exit Sub

Failed:
    failureText = "IMAGELOCAL: cannot load picture"
    ' Keep the formula intact and make an insertion failure visible.
    ' This also prevents an old photograph from appearing to be the new one.
    On Error Resume Next
    If Not picture Is Nothing Then picture.Delete
    If Not oldPicture Is Nothing Then oldPicture.Delete
    If Not box Is Nothing Then
        Set picture = ws.Shapes.AddTextbox(msoTextOrientationHorizontal, _
                                          box.Left, box.Top, box.Width, box.Height)
        picture.Name = name
        picture.AlternativeText = OWNER_TAG & vbLf & "Insertion failed"
        picture.Placement = xlMoveAndSize
        picture.Line.Visible = msoFalse
        picture.Fill.ForeColor.RGB = RGB(255, 255, 255)
        picture.TextFrame.Characters.Text = failureText
        picture.TextFrame.Characters.Font.Size = 9
        picture.TextFrame.Characters.Font.Color = RGB(160, 0, 0)
    End If
    On Error GoTo 0
End Sub

Private Sub FitPicture(ByVal picture As Shape, ByVal box As Range)
    Const padding As Double = 2
    Dim availableWidth As Double, availableHeight As Double
    availableWidth = box.Width - 2 * padding
    availableHeight = box.Height - 2 * padding
    picture.Placement = xlMoveAndSize
    If availableWidth <= 0 Or availableHeight <= 0 Then
        picture.Visible = msoFalse
        Exit Sub
    End If
    picture.Visible = msoTrue
    ' Reset the original proportions after row or column resizing.
    picture.LockAspectRatio = msoFalse
    picture.ScaleWidth 1, msoTrue, msoScaleFromTopLeft
    picture.ScaleHeight 1, msoTrue, msoScaleFromTopLeft
    picture.LockAspectRatio = msoTrue
    picture.Width = availableWidth
    If picture.Height > availableHeight Then picture.Height = availableHeight
    picture.Left = box.Left + (box.Width - picture.Width) / 2
    picture.Top = box.Top + (box.Height - picture.Height) / 2
End Sub

Public Sub ImageLocal_Refresh()
    ' Recalculate the active workbook, including unchanged IMAGELOCAL paths.
    Dim wb As Workbook, ws As Worksheet
    On Error GoTo Failed
    ImageLocal_Start
    Set wb = ActiveWorkbook
    If wb Is Nothing Then Exit Sub
    If wb Is ThisWorkbook Then Exit Sub
    For Each ws In wb.Worksheets
        ImageLocal_CleanSheet ws
        ws.Calculate
    Next ws
    ImageLocal_Flush
    Exit Sub
Failed:
    MsgBox "IMAGELOCAL could not refresh: " & Err.Description, vbExclamation
End Sub
